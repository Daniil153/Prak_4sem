#include <cmath>
#include <string>
#include <stdio.h>

class Rectangle : public Figure
{
    double a;
    double b;
public:
    Rectangle(double w, double h) : a(w), b(h) {}
    static Rectangle *make(std::string s) {
        double val1 = 0, val2 = 0;
        sscanf(s.c_str(), "%lf%lf", &val1, &val2);
        Rectangle *temp = new Rectangle(val1, val2);
        return temp;
    }
    double get_square() const override
    {
        return a * b;
    }
};

class Circle : public Figure
{
    double R;
public:
    Circle(double r) : R(r) {}
    static Circle *make(std::string s) {
        double val1 = 0;
        sscanf(s.c_str(), "%lf", &val1);
        Circle *temp = new Circle(val1);
        return temp;
    }
    double get_square() const override
    {
        return R * R * M_PI;
    }
};

class Square : public Figure
{
    double a;
public:
    Square(double b) : a(b) {}
    static Square *make(std::string s) {
        double val1 = 0;
        sscanf(s.c_str(), "%lf", &val1);
        Square *temp = new Square(val1);
        return temp;
    }
    double get_square() const override
    {
        return a * a;
    }
};

