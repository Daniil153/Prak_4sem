#include <iostream>
#include <vector>
#include <string>
#include <math.h>
#include "cmc_complex.h"
#include "cmc_complex_stack.h"
#include "cmc_complex_eval.h"

int main(int argc, char *argv[]) {
    numbers::complex C(argv[1]);
    double R;
    sscanf(argv[2], "%lf", &R);
    int N;
    sscanf(argv[3], "%d", &N);
    numbers::complex ans(0, 0);
    double h = 2 * M_PI / N;
    std::vector <std::string> vec;
    numbers::complex val;
    for (int i = 4; i < argc; i++) {
        vec.push_back(argv[i]);
    }
    for (int i = 0; i < N; i++) {
        numbers::complex xi(R * cos(h * i) + C.re(), C.im() + R * sin(h * i));
        numbers::complex xi1(R * cos(h * (i + 1)) + C.re(), C.im() + R * sin(h * (i + 1)));
        val = numbers::eval(vec, (xi + xi1) / 2) * (xi1 - xi);
        ans += val;
    }
    std::string s = ans.to_string();
    std::cout << s << std::endl;
    return 0;
}
