#include <string>
#include <vector>
#include <map>
#include <functional>

namespace numbers {
    complex eval(const std::vector <std::string> &args, const complex &z) {
        std::map <char, std::function<void(complex_stack &a, const complex &b)>> m;
        complex_stack A;
        m['*'] = [](complex_stack &a, const complex &z) {
            complex b = +a;
            a = ~a;
            b *= +a;
            a = ~a;
            a = a << b;
        };
        m['+'] = [](complex_stack &a, const complex &z) {
            complex b = +a;
            a = ~a;
            b += +a;
            a = ~a;
            a = a << b;
        };
        m['-'] = [](complex_stack &a, const complex &z) {
            complex b = +a;
            a = ~a;
            b -= +a;
            a = ~a;
            a = a << -b;
        };
        m['/'] = [](complex_stack &a, const complex &z) {
            complex b = +a;
            a = ~a;
            complex b1 = +a;
            b1 /= b;
            a = ~a;
            a = a << b1;
        };
        m['z'] = [](complex_stack &a, const complex &z) {
            a = a << z;
        };
        m['!'] = [](complex_stack &a, const complex &z) {
            a = a << +a;
        };
        m[';'] = [](complex_stack &a, const complex &z) {
            a = ~a;
        };
        m['~'] = [](complex_stack &a, const complex &z) {
            complex b = +a;
            a = ~a;
            a = a << ~b;
        };
        m['#'] = [](complex_stack &a, const complex &z) {
            complex b = +a;
            a = ~a;
            a = a << -b;
        };
        m['('] = [](complex_stack &a, const complex &z) {
            a = a << z;
        };
        for (int i = 0; i < int(args.size()); i++) {
            if (args[i][0] != '(') {
                m[args[i][0]](A, z);
            } else {
                m[args[i][0]](A, complex(args[i]));
            }
        }
        complex val;
        val = A[0];
        return val;
    }
}
