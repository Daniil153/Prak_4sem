#include <cmath>
#include <string>

enum { BUF_SIZE = 10000 };

namespace numbers {
    class complex {
        double re_ = 0, im_ = 0;
    public:
        complex(double a = 0, double b = 0) { re_ = a; im_ = b; }
        explicit complex(std::string str) : re_(0), im_(0) {
            sscanf(str.c_str(), "(%lf,%lf)", &re_, &im_);
        }
        double re() const { return re_; }
        double im() const { return im_; }
        double abs2() const { return re_ * re_ + im_ * im_; }
        double abs() const { return sqrt(re_ * re_ + im_ * im_); }
        std::string to_string() const {
            char *buf = new char[BUF_SIZE];
            std::snprintf(buf, BUF_SIZE, "(%.10g,%.10g)", re_, im_);
            std::string s = buf;
            delete [] buf;
            return s;
        }
        const complex &operator += (const complex &c)
        {
            re_ += c.re_;
            im_ += c.im_;
            return *this;
        }
        const complex &operator -= (const complex &c)
        {
            re_ -= c.re_;
            im_ -= c.im_;
            return *this;
        }
        const complex &operator *= (const complex &c)
        {
            double t = re_;
            re_ = re_ * c.re_ - im_ * c.im_;
            im_ = t * c.im_ + im_ * c.re_;
            return *this;
        }
        const complex &operator /= (const complex &c)
        {
            double t = re_;
            double r = c.re_ * c.re_ + c.im_ * c.im_;
            re_ = (re_ * c.re_ + im_ * c.im_) / r;
            im_ = (im_ * c.re_ - t * c.im_) / r;
            return *this;
        }
        complex operator - () const {
            return complex(-re_, -im_);
        }
        complex operator ~ () const {
            return complex(re_, -im_);
        }
        friend complex operator +(complex v1, const complex &v2);
        friend complex operator -(complex v1, const complex &v2);
        friend complex operator *(complex v1, const complex &v2);
        friend complex operator /(complex v1, const complex &v2);

    };
    complex operator +(complex v1, const complex &v2) {
        complex c{v1.re_, v1.im_};
        return c += v2;
    }
    complex operator -(complex v1, const complex &v2) {
        complex c{v1.re_, v1.im_};
        return c -= v2;
    }
    complex operator *(complex v1, const complex &v2) {
        complex c{v1.re_, v1.im_};
        return c *= v2;
    }
    complex operator /(complex v1, const complex &v2) {
        complex c{v1.re_, v1.im_};
        return c /= v2;
    }
}
