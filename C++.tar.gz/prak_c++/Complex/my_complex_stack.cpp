#include <iostream>
#include <cstring>

namespace numbers {
    class complex_stack {
        size_t sz{};
        size_t top{};
        complex *ptr{};
    public:
        complex_stack(size_t sz_ = 10) {
            if (sz_ == 0) {
                ptr = nullptr;
                sz = 0;
                top = 0;
            } else {
                ptr = (complex *) operator new[](sz_ * sizeof(*ptr));
                sz = sz_;
                top = 0;
            }
        }
        complex_stack(const complex_stack &temp)  {
            ptr = (complex *) operator new [] (temp.sz * sizeof(*ptr));
            top = temp.top;
            sz = temp.sz;
            memcpy(ptr, temp.ptr, top * sizeof(*ptr));
        }
        ~complex_stack() {
            if (ptr != nullptr) {
                operator delete[](ptr);
            }
        }
        size_t size() const { return top; }
        complex operator [] (size_t index) const {
            return ptr[index];
        }
        complex_stack &operator =(const complex_stack &temp) {
            if (this == &temp)
                return *this;
            complex_stack tmp(temp);
            std::swap(this->ptr, tmp.ptr);
            std::swap(this->top, tmp.top);
            std::swap(this->sz, tmp.sz);
            return *this;
        }
        complex_stack &operator =(complex_stack &&temp) {
            if (this == &temp)
                return *this;
            std::swap(this->ptr, temp.ptr);
            std::swap(this->top, temp.top);
            std::swap(this->sz, temp.sz);
            return *this;
        }
        complex operator +() const {
            return this->ptr[this->top - 1];
        }
        complex_stack operator << (complex b) const {
            if (this->top == this->sz) {
                complex_stack A(this->sz * 2);
                A.top = this->top + 1;
                memcpy(A.ptr, this->ptr, this->top * sizeof(b));
                A.ptr[this->top] = b;
                A.sz = this->sz * 2;
                return A;
            } else {
                complex_stack A(*this);
                A.ptr[A.top++] = b;
                return A;
            }
        }
        complex_stack operator ~() const {
            complex_stack A(*this);
            A.top--;
            return A;
        }
    };
}
