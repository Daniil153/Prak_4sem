#include <algorithm>
#include <vector>

template <typename T, typename K>
K myremove (T T_it1, T T_it2, K K_it1, K K_it2) {
    if (T_it1 == T_it2 || K_it1 == K_it2) {
        return K_it2;
    }
    std::vector<int> vec(T_it1, T_it2);
    std::sort(vec.begin(), vec.end());
    auto last = unique(vec.begin(), vec.end());
    auto it = vec.begin();
    while (*it < 0) {
        it++;
        if (it == last) {
            return K_it2;
        }
    }
    int count = 0;
    auto itK = K_it1;
    auto start = K_it1;
    while (start != K_it2) {
        if (*it != count || it == last) {
            std::swap(*start, *itK);
            ++itK;
        } else {
            it++;
        }
        count++;
        start++;
    }
    return itK;
}

