#include <vector>
#include <functional>

template <typename T, typename F>
void myapply (T it_begin, T it_end, F f) {
    for (auto it = it_begin; it != it_end; ++it) {
        f(*it);
    }
}

template <typename T, typename F>
auto myfilter2 (T it_begin, T it_end, F f) {
    std::vector <std::reference_wrapper <typename std::iterator_traits<T>:: value_type> > vec;
    for (auto it = it_begin; it != it_end; ++it) {
        if (f(*it)) {
            vec.insert(vec.end(), std::ref(*it));
        }
    }
    return vec;
}
