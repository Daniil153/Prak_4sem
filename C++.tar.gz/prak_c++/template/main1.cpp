template <typename T>
auto process (const T &mas) {
    typename T::value_type sum = {};
    auto it = mas.end();
    it--;
    if (mas.size() > 0) {
        sum += *it;
    }
    if (mas.size() > 2) {
        advance(it, -2);
        sum += *it;
    }
    if (mas.size() > 4) {
        advance(it, -2);
        sum += *it;
    }
    return sum;
}
