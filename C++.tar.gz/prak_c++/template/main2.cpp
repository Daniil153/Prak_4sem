#include <functional>

template <typename T>
T myfilter (const T &mas, std::function <bool(typename T::value_type)> f) {
    T new_mas;
    auto it = mas.begin();
    while (it != mas.end()) {
        if (f(*it)) {
            new_mas.insert(new_mas.end(), *it);
        }
        it++;
    }
    return new_mas;
}
