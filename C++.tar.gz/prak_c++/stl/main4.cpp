#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

enum { PER = 10 };

struct Sum {
    double sum{};
    int num{};
    Sum() { sum = 0.0; num = 0; }
    void operator()(double n) { sum += n; num++; }
};

bool comp (const double &a, const double &b) {
    return a < b;
}

int main() {
    std::vector <double> vec;
    double temp;
    while (std::cin >> temp) {
        vec.push_back(temp);
    }
    int k = int(vec.size()) / PER;
    std::sort(vec.begin() + k, vec.end() - k, comp);
    int newk = (int(vec.size()) - 2 * k) / PER;
    Sum s = std::for_each(vec.begin() + newk + k, vec.end() - newk - k, Sum());
    double ans = s.sum / s.num;
    std::cout << std::setprecision(10) << std::fixed << ans << std::endl;
    return 0;
}
