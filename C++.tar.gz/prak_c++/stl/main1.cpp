#include <vector>
#include <cstdint>

void process(const std::vector<uint64_t> &vec, std::vector<uint64_t> &vec2, int h) {

    auto it1 = vec.begin();
    auto it2 = vec.end();
    auto it3 = vec2.rbegin();
    auto it4 = vec2.rend();
    while (it1 < it2 && it3 != it4) {
        *it3 += *it1;
        if (int(std::distance(it1, it2)) > h) {
            it1 += h;
        } else {
            break;
        }
        ++it3;
    }
}
