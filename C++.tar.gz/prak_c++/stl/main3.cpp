#include <vector>
#include <algorithm>

void process(const std::vector <int> &v1, std::vector<int> &v2) {
    if (v1.empty() || v2.empty()) {
        return;
    }
    std::vector <int> vec(v1);
    std::sort(vec.begin(), vec.end());
    auto last = std::unique(vec.begin(), vec.end());
    auto it1 = vec.begin();
    while (*it1 < 0) {
        it1++;
        if (it1 == last) {
            return;
        }
    }
    int count1 = 0;
    auto it = v2.begin();
    auto itc = v2.begin();
    auto it2 = v2.end();
    while (it != it2) {
        if (*it1 != count1 || it1 == last) {
            std::swap(*it, *itc);
            itc++;
        } else {
            it1++;
        }
        it++;
        count1++;
    }
    v2.erase(itc, v2.end());
}
