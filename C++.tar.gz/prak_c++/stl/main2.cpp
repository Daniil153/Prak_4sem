#include <vector>
#include <cstdint>

void process(std::vector <int64_t> &vec, int64_t h) {
    if (vec.empty()) {
        return;
    }
    size_t count = 0;
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        if (*it >= h) {
            count++;
        }
    }
    vec.reserve(vec.size() + count);
    auto it1 = vec.end() - 1;
    auto it2 = vec.begin();
    while (it1 != it2) {
        if (*it1 >= h) {
            vec.push_back(*it1);
        }
        --it1;
    }
    if (*it1 >= h) {
        vec.push_back(*it1);
    }
}
